package com.example.chefspassion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.truecaller.android.sdk.ITrueCallback;
import com.truecaller.android.sdk.TrueError;
import com.truecaller.android.sdk.TrueProfile;
import com.truecaller.android.sdk.TruecallerSDK;
import com.truecaller.android.sdk.TruecallerSdkScope;

import java.util.Locale;

import static android.view.View.VISIBLE;
import static com.truecaller.android.sdk.TruecallerSDK.getInstance;

public class MainActivity extends AppCompatActivity {

    com.google.android.gms.common.SignInButton loginButton;
    public static GoogleSignInClient mGoogleSignInClient;
    Intent intent;
    Locale locale;
//    static MainActivity mainActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        locale=new Locale("en");
        TruecallerSdkScope trueScope = new TruecallerSdkScope.Builder(this, sdkCallback)
                .consentMode(TruecallerSdkScope.CONSENT_MODE_POPUP )
                .consentTitleOption( TruecallerSdkScope.SDK_CONSENT_TITLE_SIGN_UP )
                .footerType( TruecallerSdkScope.FOOTER_TYPE_SKIP )
                .sdkOptions( TruecallerSdkScope.SDK_OPTION_WITH_OTP )
                .build();

        TruecallerSDK.init(trueScope);


        intent=new Intent(this,UserFirstPage.class);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if(account!=null){
            Log.w("phaniraj", account.getDisplayName());
            startActivity(intent);

        }
//        mainActivity=new MainActivity();
        loginButton=findViewById(R.id.sign_in_button);
//        loginButton.setOnClickListener((View.OnClickListener) this);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signinHere();
            }
        });


    }



    public void signinHere(){
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, 1);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        getInstance().onActivityResultObtained(this, resultCode, data);
        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == 1) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            Log.w("phaniraj", account.getDisplayName());
            startActivity(intent);
            // Signed in successfully, show authenticated UI.
//            updateUI(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w("phaniraj", "signInResult:failed code=" + e.getStatusCode());
//            updateUI(null);
        }
    }

    private final ITrueCallback sdkCallback = new ITrueCallback() {

        @Override
        public void onSuccessProfileShared(@NonNull final TrueProfile trueProfile) {
            Log.d("phaniraj",trueProfile.phoneNumber.toString());
            Log.d("phaniraj",trueProfile.email);
            Log.d("phaniraj",trueProfile.lastName);
        }

        @Override
        public void onFailureProfileShared(@NonNull final TrueError trueError) {
            Log.d("phaniraj",String.valueOf(trueError.getClass()));

        }

        @Override
        public void onVerificationRequired() {
            Log.d("phaniraj","failed");
        }

    };

    public void trucallerCall(View view){
        if(getInstance().isUsable()){
            TruecallerSDK.getInstance().setLocale(locale);
            TruecallerSDK.getInstance().getUserProfile(MainActivity.this);
        }
    }


}
